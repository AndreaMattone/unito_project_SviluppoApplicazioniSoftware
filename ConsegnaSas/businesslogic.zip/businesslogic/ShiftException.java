package businesslogic;

public class ShiftException extends Exception{
}
