package businesslogic.menu;

public class MenuException extends Exception {
}
