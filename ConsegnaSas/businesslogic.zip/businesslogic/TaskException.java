package businesslogic;

public class TaskException extends Exception {
}
